<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<jsp:include page="_top.jsp"><jsp:param name="title" value="Cart"/></jsp:include>
<h2>Your cart</h2>
<c:choose>
<c:when test="${empty sessionScope.cart or sessionScope.cart.empty}">
  <p class="empty">Your cart is empty. <a href="menu">Pick something from the menu.</a></p>
</c:when>
<c:otherwise>
  <div class="scroll"><table>
    <thead><tr><th>Item</th><th>Price</th><th>Qty</th><th>Subtotal</th><th></th></tr></thead>
    <tbody>
    <c:forEach var="l" items="${sessionScope.cart.lines}">
      <tr>
        <td><c:out value="${l.item.name}"/></td>
        <td><fmt:formatNumber value="${l.item.price}" type="currency" currencySymbol="$"/></td>
        <td>
          <form method="post" action="cart" class="inline">
            <input type="hidden" name="action" value="update"><input type="hidden" name="id" value="${l.item.id}">
            <input class="qtyin" type="number" name="qty" value="${l.qty}" min="0" max="20" onchange="this.form.submit()">
          </form>
        </td>
        <td><fmt:formatNumber value="${l.subtotal}" type="currency" currencySymbol="$"/></td>
        <td>
          <form method="post" action="cart" class="inline">
            <input type="hidden" name="action" value="remove"><input type="hidden" name="id" value="${l.item.id}">
            <button class="link danger" type="submit">Remove</button>
          </form>
        </td>
      </tr>
    </c:forEach>
    </tbody>
    <tfoot><tr><th colspan="3">Total</th><th colspan="2"><fmt:formatNumber value="${sessionScope.cart.total}" type="currency" currencySymbol="$"/></th></tr></tfoot>
  </table></div>
  <form class="card" method="post" action="orders">
    <label>Name for the order<input name="customer" required maxlength="80" placeholder="e.g. Priya"></label>
    <div class="row">
      <button type="submit">Place order</button>
      <a class="btn ghost" href="menu">Keep browsing</a>
    </div>
  </form>
  <form method="post" action="cart"><input type="hidden" name="action" value="clear"><button class="link danger" type="submit">Empty cart</button></form>
</c:otherwise>
</c:choose>
<jsp:include page="_bottom.jsp"/>
