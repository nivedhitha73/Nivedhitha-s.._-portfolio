<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<jsp:include page="_top.jsp"><jsp:param name="title" value="Order"/></jsp:include>
<c:if test="${param.placed == '1'}"><p class="notice">Order placed. We are scooping it now.</p></c:if>
<h2>Order #${order.id}</h2>
<p class="muted">For <c:out value="${order.customer}"/> &middot; <fmt:formatDate value="${order.createdAt}" pattern="d MMM yyyy, HH:mm"/></p>
<div class="scroll"><table>
  <thead><tr><th>Item</th><th>Price</th><th>Qty</th><th>Subtotal</th></tr></thead>
  <tbody>
  <c:forEach var="l" items="${order.lines}">
    <tr><td><c:out value="${l.name}"/></td>
        <td><fmt:formatNumber value="${l.price}" type="currency" currencySymbol="$"/></td>
        <td>${l.qty}</td>
        <td><fmt:formatNumber value="${l.subtotal}" type="currency" currencySymbol="$"/></td></tr>
  </c:forEach>
  </tbody>
  <tfoot><tr><th colspan="3">Total</th><th><fmt:formatNumber value="${order.total}" type="currency" currencySymbol="$"/></th></tr></tfoot>
</table></div>
<p><a class="btn" href="menu">Order more</a> <a class="btn ghost" href="orders">All recent orders</a></p>
<jsp:include page="_bottom.jsp"/>
