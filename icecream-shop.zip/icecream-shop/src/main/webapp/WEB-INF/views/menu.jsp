<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<jsp:include page="_top.jsp"><jsp:param name="title" value="Menu"/></jsp:include>
<h2>Menu</h2>
<c:if test="${not empty param.added}"><p class="notice"><c:out value="${param.added}"/> added to your cart. <a href="cart">View cart</a></p></c:if>
<c:forEach var="cat" items="${menu}">
  <h3><c:out value="${cat.key}"/></h3>
  <div class="grid">
    <c:forEach var="m" items="${cat.value}">
      <form class="item" method="post" action="cart">
        <input type="hidden" name="action" value="add">
        <input type="hidden" name="id" value="${m.id}">
        <div>
          <strong><c:out value="${m.name}"/></strong>
          <p class="muted"><c:out value="${m.description}"/></p>
        </div>
        <div class="buy">
          <span class="price"><fmt:formatNumber value="${m.price}" type="currency" currencySymbol="$"/></span>
          <label class="qty">Qty <input type="number" name="qty" value="1" min="1" max="20"></label>
          <button type="submit">Add to cart</button>
        </div>
      </form>
    </c:forEach>
  </div>
</c:forEach>
<jsp:include page="_bottom.jsp"/>
