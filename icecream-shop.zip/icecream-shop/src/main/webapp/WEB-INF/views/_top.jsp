<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
  <title><c:out value="${param.title}"/> | Scoop Street</title>
  <link rel="stylesheet" href="css/style.css">
  <script src="js/theme.js"></script>
</head>
<body>
<header class="bar">
  <a class="brand" href="menu">Scoop Street</a>
  <nav>
    <a href="menu">Menu</a>
    <a href="orders">Recent orders</a>
    <a href="cart" class="cartlink">Cart <span class="badge"><c:out value="${empty sessionScope.cart ? 0 : sessionScope.cart.count}"/></span></a>
    <button id="modeBtn" class="ghost" type="button" aria-label="Toggle dark mode">Dark mode</button>
  </nav>
</header>
<main>
