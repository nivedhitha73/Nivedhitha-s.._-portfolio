<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<jsp:include page="_top.jsp"><jsp:param name="title" value="Recent orders"/></jsp:include>
<h2>Recent orders</h2>
<c:if test="${empty orders}"><p class="empty">No orders yet. <a href="menu">Place the first one.</a></p></c:if>
<c:forEach var="o" items="${orders}">
  <article class="order">
    <div class="head">
      <a href="orders?id=${o.id}"><strong>Order #${o.id}</strong></a>
      <span class="muted"><c:out value="${o.customer}"/> &middot; <fmt:formatDate value="${o.createdAt}" pattern="d MMM yyyy, HH:mm"/></span>
      <span class="price"><fmt:formatNumber value="${o.total}" type="currency" currencySymbol="$"/></span>
    </div>
    <p class="muted"><c:forEach var="l" items="${o.lines}" varStatus="st">${l.qty} x <c:out value="${l.name}"/><c:if test="${!st.last}">, </c:if></c:forEach></p>
  </article>
</c:forEach>
<jsp:include page="_bottom.jsp"/>
