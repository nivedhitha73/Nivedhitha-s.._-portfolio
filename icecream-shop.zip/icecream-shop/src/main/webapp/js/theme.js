// Dark / light mode: remembers the choice, defaults to the system setting.
(function () {
  var saved = localStorage.getItem('theme');
  var dark = saved ? saved === 'dark' : window.matchMedia('(prefers-color-scheme: dark)').matches;
  function apply(d) {
    document.documentElement.setAttribute('data-theme', d ? 'dark' : 'light');
    var b = document.getElementById('modeBtn');
    if (b) b.textContent = d ? 'Light mode' : 'Dark mode';
  }
  apply(dark);
  document.addEventListener('DOMContentLoaded', function () {
    apply(dark);
    document.getElementById('modeBtn').addEventListener('click', function () {
      dark = !dark; localStorage.setItem('theme', dark ? 'dark' : 'light'); apply(dark);
    });
  });
})();
